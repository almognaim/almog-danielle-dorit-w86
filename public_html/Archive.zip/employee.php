<?php include 'inc/header/header.php'; ?>

     <!-- Main Start -->

     <main class="page-content">
            <div class="container-fluid">
                    <div class="row" id="page-title">
                        <div class="col-12">
                            <h1>עובדים</h1>
                        </div>
                    </div>
            </div>

        </main>

        <!-- Main End -->

<?php include 'inc/footer/footer.php'; ?>