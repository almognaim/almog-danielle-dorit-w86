<?php include 'inc/header/header.php' ?>

<!-- Main Start -->

<main class="page-content">
    <div class="container-fluid">
        <div class="row" id="page-title">
            <div class="col-12">
                <h1>דוחות ומסמכים</h1>
            </div>
        </div>
    </div>
    <div class="container" style="max-width: 900px;">
        <div class="row">

            <div class="col-md-6 col-12">


                <div class="box-part text-center">
                    <a href="inventory/suppliers.php">
                        <i class="far fa-file-alt"></i>

                        <div class="title">
                            <h4>דוחות</h4>
                        </div>

                        <div class="text">
                            <span>Lorem ipsum dolor sit amet, id quo eruditi eloquentiam. Assum decore te sed. Elitr scripta ocurreret qui ad.</span>
                        </div>

                        <a href="#">Learn More</a>
                    </a>
                </div>

            </div>

            <div class="col-md-6 col-12">



                <div class="box-part text-center">
                    <a href="clients.php">
                        <i class="fas fa-users"></i>

                        <div class="title">
                            <h4>חשבוניות </h4>
                        </div>

                        <div class="text">
                            <span>Lorem ipsum dolor sit amet, id quo eruditi eloquentiam. Assum decore te sed. Elitr scripta ocurreret qui ad.</span>
                        </div>

                        <a href="#">Learn More</a>
                    </a>
                </div>

            </div>



        </div>
    </div>

</main>

<!-- Main End -->

<?php include 'inc/footer/footer.php' ?>