<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>המוסך של יוסי</title>
    <!-- Bootstrap CSS Mini -->
    <link rel="stylesheet" href="http://localhost:8888/yossigarage/asset/bootstrap/dist/css/bootstrap.min.css">
    <!-- Fonts - CDN of google fonts api Declared in style.css -->
    <link href="https://fonts.googleapis.com/css?family=Arimo:400,700&display=swap" rel="stylesheet">
    <link href="https://use.fontawesome.com/releases/v5.0.6/css/all.css" rel="stylesheet">
    <!-- datatables css -->
    <link rel="stylesheet" href="https://cdn.datatables.net/1.10.19/css/jquery.dataTables.min.css">
    <!-- sweetAlert css -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/8.11.8/sweetalert2.min.css" integrity="sha256-2bAj1LMT7CXUYUwuEnqqooPb1W0Sw0uKMsqNH0HwMa4=" crossorigin="anonymous" />
    <!-- main Css -->
    <link rel="stylesheet" href="http://localhost:8888/yossigarage/asset/css/sidebars.css">
    <link rel="stylesheet" href="http://localhost:8888/yossigarage/asset/css/steps.css">
    <link rel="stylesheet" href="http://localhost:8888/yossigarage/asset/css/style.css">
</head>